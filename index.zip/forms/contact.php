<?php 
if (isset($_POST['submit'])) {
    // Database connection
    $conn = new mysqli("localhost", "root", "", "mywebsite1_db");


    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Collect form data safely (prevent SQL injection)
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $subject = $conn->real_escape_string($_POST['subject']);
    $message = $conn->real_escape_string($_POST['message']);

    // Insert into database
    $sql = "INSERT INTO contact (name, email, subject, message) 
            VALUES ('$name', '$email', '$subject', '$message')";

    if ($conn->query($sql) === TRUE) {
        header("Location: /mywebsite1/?success=1");
        exit;
    } else {
        echo "<p style='color:red;'>❌ Error: " . $conn->error . "</p>";
    }

    $conn->close();
}
?>

<!-- HTML Form -->
<form method="POST" action="">
    <input type="text" name="name" placeholder="Your Name" required><br><br>
    <input type="email" name="email" placeholder="Your Email" required><br><br>
    <input type="text" name="subject" placeholder="Subject" required><br><br>
    <textarea name="message" placeholder="Your Message" required></textarea><br><br>
    <button type="submit" name="submit">Send</button>
</form>
